# mypackage
This library was created to see and learn how to publish my own Python package.

## building this package locally
'python setup.py sdist'

## installing this package from GitHub
'pip install git+https://github.com/ibkalao14/example-python-package.git'

## updating this package from GITHUB
'pip install --upgrade git+https://github.com/ibkalao14/example-python-package.git'
